import java.sql.*;
public class TestConnection {

	public static void main(String[] args) {
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection  conObj = DriverManager.getConnection("jdbc:mysql://localhost:3306/phase2weekenddb", "root", "root");
			if(conObj!=null)
				System.out.println("Db Connected...");
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
	}
}

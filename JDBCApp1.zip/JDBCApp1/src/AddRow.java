import java.sql.*;

public class AddRow {
//INSERT INTO STUDENT(ROLLNO, SNAME, COURSE, FEES) VALUES(1001, 'PRAVEEN', 'JAVA', 12000.00)
	public static void main(String[] args) {
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection  conObj = DriverManager.getConnection("jdbc:mysql://localhost:3306/phase2weekenddb", "root", "root");
			Statement stmt = conObj.createStatement();
			stmt.executeUpdate("INSERT INTO STUDENT(ROLLNO, SNAME, COURSE, FEES) VALUES(1001, 'PRAVEEN', 'JAVA', 12000.00)");
			System.out.println("Student Details are added...");
			conObj.close();
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}

	}

}

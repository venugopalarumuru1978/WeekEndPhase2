package com.hibernate.service;

import java.io.Serializable;
import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.hibernate.config.HibernateConfig;
import com.hibernate.models.PhoneBook;

public class PbOperations {

	private SessionFactory sfact = null;
	
	public PbOperations()
	{
		sfact = HibernateConfig.DbConnection();
	}
	
	public String AddNewPhoneBook(PhoneBook pb)
	{
		String result = "error";
		Session session = sfact.openSession();
		Transaction trans = session.beginTransaction();
		
		Serializable s = session.save(pb);
		trans.commit();
		
		if(s!=null)
			result = "Success";
		
		session.close();
		return result;
	}
	
	public List<PhoneBook> ShowAll()
	{
		Session session = sfact.openSession();
		TypedQuery  qry = session.createQuery("from PhoneBook");
		List<PhoneBook>  pball = qry.getResultList();
		
		session.close();
		return pball;
	}
	
	public PhoneBook SearchCustomer(String phonenumber)
	{
		PhoneBook pb = null;
		Session session = sfact.openSession();
		TypedQuery  qry = session.createQuery("from PhoneBook where phone=:ph");
		qry.setParameter("ph", phonenumber);
		
		List<PhoneBook>  pball = qry.getResultList();
		
		if(!pball.isEmpty())
			pb = pball.get(0);
		
		session.close();
		return pb;
	}
	
	public String DeleteCustomer(int cid)
	{
		String result = "error";
		Session session = sfact.openSession();
		Transaction trans = session.beginTransaction();
		TypedQuery  qry = session.createQuery("Delete from PhoneBook where cid=:cid");
		qry.setParameter("cid", cid);
		int res = qry.executeUpdate();
		trans.commit();
		
		if(res>=1)
			result="Success";
		
		session.close();
		return result;
	}
	
	public String UpdateStudentname(PhoneBook pb)
	{
		String result = "error";
		Session session = sfact.openSession();
		Transaction trans = session.beginTransaction();
		TypedQuery  qry = session.createQuery("Update PhoneBook set cname=:cn where cid=:cid");
		qry.setParameter("cid", pb.getCid());
		qry.setParameter("cn", pb.getCname());
		int res = qry.executeUpdate();
		trans.commit();
		
		if(res>=1)
			result="Success";
		
		session.close();
		return result;
	}
}

package com.hibernate.apps;

import java.util.Scanner;

import com.hibernate.models.PhoneBook;
import com.hibernate.service.PbOperations;

public class PhoneBookAdd {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		PhoneBook pbook = new PhoneBook();
		PbOperations pbs = new PbOperations();
		
		System.out.println("Customer Name : ");
		pbook.setCname(sc.next());
		
		System.out.println("Phone Number : ");
		pbook.setPhone(sc.next());
		
		System.out.println("Email : ");
		pbook.setEmail(sc.next());
		
		String res = pbs.AddNewPhoneBook(pbook);
		if(res.equals("Success"))
			System.out.println("Customer Added...");

	}

}

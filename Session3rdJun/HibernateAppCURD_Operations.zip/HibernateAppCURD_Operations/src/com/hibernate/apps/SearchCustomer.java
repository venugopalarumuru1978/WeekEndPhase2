package com.hibernate.apps;

import java.util.Scanner;

import com.hibernate.models.PhoneBook;
import com.hibernate.service.PbOperations;

public class SearchCustomer {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Phone Number : ");
		String ph = sc.next();
		
		PbOperations pbs = new PbOperations();
		
		PhoneBook pb = pbs.SearchCustomer(ph);
		
		if(pb!=null)
			System.out.println(pb.getCid() + "\t" + pb.getCname() + "\t" + pb.getPhone() + "\t" + pb.getEmail());
		else
			System.out.println("Customer Not Found....");
	}

}

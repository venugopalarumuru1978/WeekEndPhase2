package com.hibernate.apps;

import java.util.List;

import com.hibernate.models.PhoneBook;
import com.hibernate.service.PbOperations;

public class ShowAllCustomers {

	public static void main(String[] args) {
		PbOperations pbs = new PbOperations();
		
		List<PhoneBook>  pball = pbs.ShowAll();
		
		for(PhoneBook pb : pball)
		{
			System.out.println(pb.getCid() + "\t" + pb.getCname() + "\t" + pb.getPhone() + "\t" + pb.getEmail());
		}

	}

}

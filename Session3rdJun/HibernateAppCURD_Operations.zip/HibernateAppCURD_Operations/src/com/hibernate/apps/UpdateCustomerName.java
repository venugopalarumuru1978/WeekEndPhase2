package com.hibernate.apps;

import java.util.Scanner;

import com.hibernate.models.PhoneBook;
import com.hibernate.service.PbOperations;

public class UpdateCustomerName {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Phone Number : ");
		String ph = sc.next();
		
		PbOperations pbs = new PbOperations();
		
		PhoneBook pb = pbs.SearchCustomer(ph);
		
		if(pb!=null)
		{
			System.out.println("Present Name of Customer : " + pb.getCname());
			System.out.println("New Name of the customer ");
			pb.setCname(sc.next());
			
			String res = pbs.UpdateStudentname(pb);
			
			if(res.equals("Success"))
				System.out.println("Customer is Updated...");
		}
		else
			System.out.println("Customer Not Found....");
	}
}

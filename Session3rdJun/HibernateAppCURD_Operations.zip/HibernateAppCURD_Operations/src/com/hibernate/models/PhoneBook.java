package com.hibernate.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="PhonebookInfo")
public class PhoneBook {

	@Id   // primary key
	@GeneratedValue  // auto-increment values
	@Column(name="custid")
	private int cid;
	
	@Column(name="custname",length = 30, nullable = false)
	private String cname;
	
	@Column(name="phonenumber", length = 10, nullable = false)
	private String phone;
	
	private String email;
	
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
}

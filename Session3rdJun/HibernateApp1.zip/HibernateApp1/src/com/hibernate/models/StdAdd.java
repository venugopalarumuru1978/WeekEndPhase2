package com.hibernate.models;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class StdAdd {

	public static void main(String[] args) {
		
		Configuration cfg = new Configuration();  // it allows to read config file
		cfg.configure("hibernate.cfg.xml");
		
		SessionFactory  sfact = cfg.buildSessionFactory();
		Session session  = sfact.openSession();
		Transaction trans = session.beginTransaction();
		
		Student std = new Student();
		std.setRollno(1001);
		std.setSname("Jagan");
		std.setCourse("Python");
		std.setFees(12000.00f);
		
		session.save(std);
		trans.commit();
		
		session.close();
		sfact.close();
		
		System.out.println("Data Saved....");
	}
}

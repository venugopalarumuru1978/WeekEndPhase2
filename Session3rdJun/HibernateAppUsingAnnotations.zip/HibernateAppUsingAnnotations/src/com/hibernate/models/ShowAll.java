package com.hibernate.models;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class ShowAll {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();  // it allows to read config file
		cfg.configure("hibernate.cfg.xml");
		
		SessionFactory  sfact = cfg.buildSessionFactory();
		Session session  = sfact.openSession();
		
		TypedQuery  qry  = session.createQuery("from Student"); // Student is a classname
		
		List<Student>  sall  = qry.getResultList();
		
		for(Student s : sall)
		{
			System.out.println(s.getRollno() + "\t" + s.getSname() + "\t" + s.getCourse() + "\t" + s.getFees());
		}
		
		session.close();

	}

}

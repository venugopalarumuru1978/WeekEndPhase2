package com.hibernate.models;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class StdAddDynamic {

	public static void main(String[] args) {
		
		Configuration cfg = new Configuration();  // it allows to read config file
		cfg.configure("hibernate.cfg.xml");
		
		SessionFactory  sfact = cfg.buildSessionFactory();
		Session session  = sfact.openSession();
		Transaction trans = session.beginTransaction();
		
		Scanner sc = new Scanner(System.in);
		Student std = new Student();
		
		System.out.println("Roll Number : ");
		std.setRollno(sc.nextInt());
		System.out.println("Student Name : ");
		std.setSname(sc.next());
		System.out.println("Student Course : ");
		std.setCourse(sc.next());
		System.out.println("Course Fees : ");
		std.setFees(sc.nextFloat());
		
		session.save(std);
		trans.commit();
		
		session.close();
		sfact.close();
		
		System.out.println("Data Saved....");
	}
}

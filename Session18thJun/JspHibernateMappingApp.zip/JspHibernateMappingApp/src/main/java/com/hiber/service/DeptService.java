package com.hiber.service;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.hiber.config.HiberConfig;
import com.hiber.models.Department;

public class DeptService {

	private SessionFactory  sf=null;
	
	public DeptService()
	{
		sf = HiberConfig.getSessionFactory();
	}
	
	public void AddDept(Department dept)
	{
		Session session = sf.openSession();
		Transaction trans = session.beginTransaction();
		session.save(dept);
		trans.commit();
	}
	
	public List<Department> ShowAllDept()
	{
		Session session = sf.openSession();
		TypedQuery qry =  session.createQuery("from Department");
		List<Department>  dall = qry.getResultList();
		return  dall;
	}
	
}

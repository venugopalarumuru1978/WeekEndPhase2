package com.hiber.service;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.hiber.config.HiberConfig;
import com.hiber.models.Department;
import com.hiber.models.Employee;

public class EmpService {

private SessionFactory  sf=null;
	
	public EmpService()
	{
		sf = HiberConfig.getSessionFactory();
	}
	
	public void AddEmp(Employee emp)
	{
		Session session = sf.openSession();
		Transaction trans = session.beginTransaction();
		session.save(emp);
		trans.commit();
	}
	
	public List<Employee> ShowAllEmpsBasedOnDept(int dno)
	{
		Session session = sf.openSession();
		TypedQuery qry =  session.createQuery("from Employee where deptno=:dno");
		qry.setParameter("dno",dno);
		List<Employee>  empall = qry.getResultList();
		return  empall;
	}
}

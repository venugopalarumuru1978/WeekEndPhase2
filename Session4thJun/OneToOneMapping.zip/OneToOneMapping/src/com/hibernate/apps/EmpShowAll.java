package com.hibernate.apps;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hibernate.models.Address;
import com.hibernate.models.Employee;

public class EmpShowAll {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();  // it allows to read config file
		cfg.configure("hibernate.cfg.xml");
		
		SessionFactory  sfact = cfg.buildSessionFactory();
		Session session  = sfact.openSession();
		
		TypedQuery qry = session.createQuery("from Employee");
		
		List<Employee> empall = qry.getResultList();
		
		for(Employee e : empall)
		{
			System.out.println(e.getEmpno() + "\t"  + e.getEname() + "\t" + e.getJob() + "\t" + e.getSalary() + "\t" + e.getAdrs().getDoorno() + "\t" + e.getAdrs().getLocation());
		}
	}
}

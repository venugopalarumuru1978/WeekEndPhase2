package com.hibernate.apps;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hibernate.models.Address;
import com.hibernate.models.Course;
import com.hibernate.models.Employee;
import com.hibernate.models.Student;

public class CourseAll {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();  
		cfg.configure("hibernate.cfg.xml");
		
		SessionFactory  sfact = cfg.buildSessionFactory();
		Session session  = sfact.openSession();
		
		TypedQuery qry = session.createQuery("from Course");
		
		List<Course> curall = qry.getResultList();
		
		for(Course c : curall)
		{
			System.out.println(c.getCurid() + "\t" + c.getCurName() + "\t" + c.getDuration() + "\t" + c.getStd().getSname() + "\t" + c.getStd().getFees());
		}
	}
}

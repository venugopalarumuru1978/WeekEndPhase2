package com.hibernate.apps;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hibernate.models.Address;
import com.hibernate.models.Course;
import com.hibernate.models.Employee;
import com.hibernate.models.Student;

public class StudentApp {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();  // it allows to read config file
		cfg.configure("hibernate.cfg.xml");
		
		SessionFactory  sfact = cfg.buildSessionFactory();
		Session session  = sfact.openSession();
		Transaction trans = session.beginTransaction();
		
		Student std = new Student();
		
		std.setSname("Murali Kumar");
		std.setFees(15000.00f);
		
		Course cur = new Course();
		cur.setCurName("Python");
		cur.setDuration("4 Months");
		
		std.setCourse(cur);
		cur.setStd(std);
		
		session.persist(std);
		
		trans.commit();
		
		System.out.println("Student Info Stored...");
	}
}

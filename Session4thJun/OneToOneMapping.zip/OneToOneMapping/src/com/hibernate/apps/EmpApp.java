package com.hibernate.apps;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hibernate.models.Address;
import com.hibernate.models.Employee;

public class EmpApp {

	public static void main(String[] args) {
		Configuration cfg = new Configuration(); 
		cfg.configure("hibernate.cfg.xml");
		
		SessionFactory  sfact = cfg.buildSessionFactory();
		Session session  = sfact.openSession();
		Transaction trans = session.beginTransaction();
		
		Employee emp = new Employee();
		emp.setEname("Naresh");
		emp.setJob("Developer");
		emp.setSalary(10000.00f);
		
		Address adrs = new Address();
		adrs.setDoorno("D.No.121-B");
		adrs.setLocation("Hyderabad");
		
		emp.setAdrs(adrs);
		
		session.persist(emp);
		trans.commit();
		
		System.out.println("Emp Info Stored...");
	}
}

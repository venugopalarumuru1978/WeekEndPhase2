package com.hibernate.models;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

// Uni-Directional :-  parent to child only

@Entity
@Table(name="empsinfo")
public class Employee {

	
	@Id
	@GeneratedValue
	
	//@PrimaryKeyJoinColumn
	private int empno;
	
	private String ename;
	private String job;
	private float salary;
	
	@OneToOne(targetEntity=Address.class, cascade=CascadeType.ALL)
	private Address adrs;
	
	public Address getAdrs() {
		return adrs;
	}
	public void setAdrs(Address adrs) {
		this.adrs = adrs;
	}
	public int getEmpno() {
		return empno;
	}
	public void setEmpno(int empno) {
		this.empno = empno;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
}

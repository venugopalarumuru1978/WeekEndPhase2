package com.hibernate.models;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="courseinfo")
public class Course {

	@Id
	@GeneratedValue
	private int curid;
	private String curName;
	private String duration;
	
	@OneToOne(targetEntity=Student.class, cascade=CascadeType.ALL)
	private Student std;

	public int getCurid() {
		return curid;
	}

	public void setCurid(int curid) {
		this.curid = curid;
	}

	public String getCurName() {
		return curName;
	}

	public void setCurName(String curName) {
		this.curName = curName;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public Student getStd() {
		return std;
	}

	public void setStd(Student std) {
		this.std = std;
	}
	
	
	
}

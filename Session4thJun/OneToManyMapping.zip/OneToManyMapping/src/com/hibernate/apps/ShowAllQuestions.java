package com.hibernate.apps;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.*;

import javax.persistence.TypedQuery;

import com.hibernate.models.*;

public class ShowAllQuestions {

	public static void main(String[] args) {
		Configuration cfg = new Configuration(); 
		cfg.configure("hibernate.cfg.xml");
		
		SessionFactory  sfact = cfg.buildSessionFactory();
		Session session  = sfact.openSession();
		
		TypedQuery qry = session.createQuery("from Question");
		List<Question>  qall = qry.getResultList();
		
		for(Question q : qall)
		{
			System.out.println(q.getQuid() + ".  " + q.getQuname());
			List<Answers>  ansall = q.getAnsall();
			for(Answers a : ansall)
			{
				System.out.println(a.getAnsinfo() + " : Given By : " + a.getGivenby());
			}
			System.out.println("------------------");
		}
	}
}

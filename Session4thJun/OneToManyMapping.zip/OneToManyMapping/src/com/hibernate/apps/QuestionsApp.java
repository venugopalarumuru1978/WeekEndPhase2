package com.hibernate.apps;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.*;
import com.hibernate.models.*;

public class QuestionsApp {

	public static void main(String[] args) {
		Configuration cfg = new Configuration(); 
		cfg.configure("hibernate.cfg.xml");
		
		SessionFactory  sfact = cfg.buildSessionFactory();
		Session session  = sfact.openSession();
		Transaction trans = session.beginTransaction();
		
		Question q1 = new Question();
		q1.setQuname("What is an SQL");
		
		List<Answers>  listall = new ArrayList<Answers>();
		Answers  ans1 = new Answers();
		ans1.setAnsinfo("It is Structured Query Lang");
		ans1.setGivenby("Baskar");
		listall.add(ans1);
		
		ans1 = new Answers();
		ans1.setAnsinfo("It is Non Procedural Lang");
		ans1.setGivenby("Naresh");
		listall.add(ans1);
		
		
		q1.setAnsall(listall);
		
		session.persist(q1);
		trans.commit();
		
		System.out.println("Questions has stored");
	}
}

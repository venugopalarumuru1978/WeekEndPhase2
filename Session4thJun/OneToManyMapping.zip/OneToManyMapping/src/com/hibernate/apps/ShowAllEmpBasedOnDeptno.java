package com.hibernate.apps;

import java.util.List;
import java.util.Scanner;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.hibernate.models.Dept;
import com.hibernate.models.Emp;

public class ShowAllEmpBasedOnDeptno {

	public static void main(String[] args) {
		Configuration cfg = new Configuration(); 
		cfg.configure("hibernate.cfg.xml");
		
		SessionFactory  sfact = cfg.buildSessionFactory();
		Session session  = sfact.openSession();
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Dept Number : ");
		int dno = sc.nextInt();
		
		TypedQuery  qry = session.createQuery("from Dept where deptno=:dno");
		qry.setParameter("dno", dno);
		List<Dept>  dall = qry.getResultList();
		
		if(!dall.isEmpty())
		{
			Dept  d = dall.get(0);
			
			System.out.println(d.getDeptname());
			System.out.println("-------------");
			List<Emp>  empall = d.getEmps();
			
			for(Emp e : empall)
			{
				System.out.println(e.getEmpno() + "\t" + e.getEname());
			}
		}	
		else
			System.out.println("No Department Found...");

	}

}

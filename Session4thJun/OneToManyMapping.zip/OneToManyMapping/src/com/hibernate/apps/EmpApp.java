package com.hibernate.apps;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.*;
import com.hibernate.models.*;

public class EmpApp {

	public static void main(String[] args) {
		Configuration cfg = new Configuration(); 
		cfg.configure("hibernate.cfg.xml");
		
		SessionFactory  sfact = cfg.buildSessionFactory();
		Session session  = sfact.openSession();
		Transaction trans = session.beginTransaction();
		
		Dept  dept1 = new Dept();
		dept1.setDeptname("Education");
		
		List<Emp>  empall = new ArrayList<Emp>();
		Emp emp = new Emp();
		emp.setEname("Praveen");
		empall.add(emp);
		
		emp = new Emp();
		emp.setEname("Pavan");
		empall.add(emp);
		
		emp = new Emp();
		emp.setEname("Paramesh");
		empall.add(emp);
		
		dept1.setEmps(empall);
		
		Dept  dept2 = new Dept();
		dept2.setDeptname("Research");
		
		List<Emp>  empall1 = new ArrayList<Emp>();
		emp = new Emp();
		emp.setEname("Kavitha");
		empall1.add(emp);
		
		emp = new Emp();
		emp.setEname("Kalyani");
		empall1.add(emp);

		emp = new Emp();
		emp.setEname("Kamala");
		empall1.add(emp);

		dept2.setEmps(empall1);
		
		session.persist(dept1);
		session.persist(dept2);
		trans.commit();
		
		System.out.println("All Emps are Saved...");
	}
}

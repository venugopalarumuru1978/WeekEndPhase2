package com.hibernate.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="answersinfo")
public class Answers {

	@Id
	@GeneratedValue
	private int ansid;
	
	private String ansinfo;
	private String givenby;
	
	public int getAnsid() {
		return ansid;
	}
	public void setAnsid(int ansid) {
		this.ansid = ansid;
	}
	public String getAnsinfo() {
		return ansinfo;
	}
	public void setAnsinfo(String ansinfo) {
		this.ansinfo = ansinfo;
	}
	public String getGivenby() {
		return givenby;
	}
	public void setGivenby(String givenby) {
		this.givenby = givenby;
	}
	
	
}

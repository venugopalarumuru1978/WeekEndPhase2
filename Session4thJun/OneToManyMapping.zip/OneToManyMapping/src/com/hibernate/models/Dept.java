package com.hibernate.models;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OrderColumn;
import javax.persistence.Table;

@Entity
@Table(name="dept_info")
public class Dept {

	@Id
	@GeneratedValue
	private int deptno;
	private String deptname;
	
	@OneToMany(targetEntity=Emp.class, cascade=CascadeType.ALL)
	@JoinColumn(name="deptno")
	//@OrderColumn(name="indval")
	private List<Emp>  emps;

	public int getDeptno() {
		return deptno;
	}

	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}

	public String getDeptname() {
		return deptname;
	}

	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}

	public List<Emp> getEmps() {
		return emps;
	}

	public void setEmps(List<Emp> emps) {
		this.emps = emps;
	}
	
	
}

package com.hibernate.models;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="VechInfo")
public class Vechicle {

	@Id
	@GeneratedValue
	private int vehId;
	private String vechName;
	private String brand;
	
	@ManyToOne(cascade=CascadeType.ALL)
	private Owner owner;

	public int getVehId() {
		return vehId;
	}

	public void setVehId(int vehId) {
		this.vehId = vehId;
	}

	public String getVechName() {
		return vechName;
	}

	public void setVechName(String vechName) {
		this.vechName = vechName;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public Owner getOwner() {
		return owner;
	}

	public void setOwner(Owner owner) {
		this.owner = owner;
	}
	
	
}

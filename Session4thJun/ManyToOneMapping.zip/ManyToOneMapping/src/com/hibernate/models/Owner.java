package com.hibernate.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="OwnerInfo")
public class Owner {

	@Id
	@GeneratedValue
	private int ownid;
	private String OwnerName;
	
	public int getOwnid() {
		return ownid;
	}
	public void setOwnid(int ownid) {
		this.ownid = ownid;
	}
	public String getOwnerName() {
		return OwnerName;
	}
	public void setOwnerName(String ownerName) {
		OwnerName = ownerName;
	}
}

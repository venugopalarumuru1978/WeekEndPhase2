package com.hibernate.apps;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hibernate.models.Owner;
import com.hibernate.models.Vechicle;

public class VechApp {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		
		SessionFactory  sfact = cfg.buildSessionFactory();
		Session session  = sfact.openSession();
		Transaction trans = session.beginTransaction();
		
		Owner  own1 = new Owner();
		own1.setOwnerName("Kamala Devi");
		
		Vechicle v1 = new Vechicle();
		v1.setVechName("Audi Car");
		v1.setBrand("Brand-1");
		v1.setOwner(own1);
		
		Vechicle v2 = new Vechicle();
		v2.setVechName("RollsRoyecee  Car");
		v2.setBrand("Brand-2");
		v2.setOwner(own1);
		
		session.persist(v1);
		session.persist(v2);
		trans.commit();
		
		System.out.println("Data Saved....");
		
	}
}

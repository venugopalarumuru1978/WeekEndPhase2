package com.hibernate.apps;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hibernate.models.Owner;
import com.hibernate.models.Vechicle;

public class ViewVechAll {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		
		SessionFactory  sfact = cfg.buildSessionFactory();
		Session session  = sfact.openSession();
		
		TypedQuery qry =  session.createQuery("from Vechicle");
		
		List<Vechicle>  vall = qry.getResultList();
		
		for(Vechicle v : vall)
		{
			System.out.println(v.getVechName() + "\t" + v.getBrand() + "\t" + v.getOwner().getOwnerName());
		}		
	}
}

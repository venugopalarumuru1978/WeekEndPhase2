package com.hibernate.models;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="course_std")
public class Course {

	@Id
	@GeneratedValue
	private int curid;
	
	private String curname;
	private String duration;
	
	@ManyToMany(cascade=CascadeType.ALL)
	public List<Student>  stdinfo;

	public int getCurid() {
		return curid;
	}

	public void setCurid(int curid) {
		this.curid = curid;
	}

	public String getCurname() {
		return curname;
	}

	public void setCurname(String curname) {
		this.curname = curname;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public List<Student> getStdinfo() {
		return stdinfo;
	}

	public void setStdinfo(List<Student> stdinfo) {
		this.stdinfo = stdinfo;
	}
	
}

package com.hibernate.models;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="std_course")
public class Student {

	@Id
	@GeneratedValue
	private int rollno;
	
	private String sname;
	private String location;
	
	@ManyToMany(cascade=CascadeType.ALL)
	private List<Course>  courseinfo;

	public int getRollno() {
		return rollno;
	}

	public void setRollno(int rollno) {
		this.rollno = rollno;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public List<Course> getCourseinfo() {
		return courseinfo;
	}

	public void setCourseinfo(List<Course> courseinfo) {
		this.courseinfo = courseinfo;
	}
	
	
}

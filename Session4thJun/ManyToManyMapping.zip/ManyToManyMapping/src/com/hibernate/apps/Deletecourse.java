package com.hibernate.apps;

import java.util.List;
import java.util.Scanner;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hibernate.models.Course;
import com.hibernate.models.Student;

public class Deletecourse {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();  
		cfg.configure("hibernate.cfg.xml");
		
		SessionFactory  sfact = cfg.buildSessionFactory();
		Session session  = sfact.openSession();
		Transaction trans = session.beginTransaction();
		
		Scanner sc = new Scanner(System.in);
	
		System.out.println("Enter Course ID : ");
		int cno = sc.nextInt();
		
		TypedQuery  qry = session.createQuery("from Course where curid=:cno");
		qry.setParameter("cno", cno);
		
		List<Course> cur = qry.getResultList();
		
		if(!cur.isEmpty())
		{
			Course c = cur.get(0);
			session.delete(c);
			trans.commit();
			System.out.println("Course is Deleted....");
		}
		else
			System.out.println("Course Not Found...");
	}
}

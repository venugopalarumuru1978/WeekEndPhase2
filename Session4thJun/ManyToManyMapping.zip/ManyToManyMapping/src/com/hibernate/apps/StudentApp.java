package com.hibernate.apps;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hibernate.models.Course;
import com.hibernate.models.Student;


public class StudentApp {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();  
		cfg.configure("hibernate.cfg.xml");
		
		SessionFactory  sfact = cfg.buildSessionFactory();
		Session session  = sfact.openSession();
		Transaction trans = session.beginTransaction();
		
		List<Student>  stdinfo = new ArrayList<Student>();
		List<Course>  courseinfo = new ArrayList<Course>();
		
		Student std = new Student();
		std.setSname("Jagan");
		std.setLocation("Hyd");
		stdinfo.add(std);
		
		Student std1 = new Student();
		std1.setSname("Pavan");
		std1.setLocation("Bangalore");
		stdinfo.add(std1);
		
		Student std2 = new Student();
		std2.setSname("Sarala");
		std2.setLocation("Hyd");
		stdinfo.add(std2);
		
		Course cur =new Course();
		cur.setCurname("Java");
		cur.setDuration("6 Months");
		courseinfo.add(cur);
		
		Course cur1 =new Course();
		cur1.setCurname("Python");
		cur1.setDuration("5 Months");
		courseinfo.add(cur1);
		
		std.setCourseinfo(courseinfo);
		std1.setCourseinfo(courseinfo);
		std2.setCourseinfo(courseinfo);
		
		cur.setStdinfo(stdinfo);
		cur1.setStdinfo(stdinfo);
		
		
		session.persist(std);
		session.persist(std1);
		session.persist(std2);
		session.persist(cur1);
		session.persist(cur);
		trans.commit();
		
		System.out.println("Data Saved...");
	}
}

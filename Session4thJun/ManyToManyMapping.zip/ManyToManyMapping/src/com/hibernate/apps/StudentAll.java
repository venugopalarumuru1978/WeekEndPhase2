package com.hibernate.apps;


import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import org.hibernate.cfg.Configuration;

import com.hibernate.models.Course;
import com.hibernate.models.Student;


public class StudentAll {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();  
		cfg.configure("hibernate.cfg.xml");
		
		SessionFactory  sfact = cfg.buildSessionFactory();
		Session session  = sfact.openSession();

		TypedQuery  qry = session.createQuery("from Student");
		
		List<Student> s_all = qry.getResultList();
		
		for(Student s : s_all)
		{
			System.out.println(s.getRollno() + "\t" + s.getSname() + "\t" + s.getLocation());
			List<Course> cur =  s.getCourseinfo();
			System.out.println("Courses Joined : ");
			for(Course c : cur)
			{
				System.out.println(c.getCurid() + "\t" + c.getCurname() + "\t" + c.getDuration());
			}
			System.out.println("----------------");
		}
	}
}

package com.jdbc.EmpApp;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EmpOperations {

	private Connection conObj=null;
	// constructor which meant for db connection
	public EmpOperations()
	{
		conObj = DbConnection.GetDbConnection();
	}
	
	public String AddNewEmployee(Employee emp)
	{
		String result = "Error";
		
		try
		{
			PreparedStatement ps = conObj.prepareStatement("Insert into Employee(empname, job, salary, location) values(?,?,?,?)");
			ps.setString(1, emp.getEname());
			ps.setString(2, emp.getJob());
			ps.setInt(3, emp.getSalary());
			ps.setString(4, emp.getLocation());
			
			int res = ps.executeUpdate();
			
			if(res>=1)
				result = "Success";
		}
		catch(Exception ex)
		{
			result = ex.getMessage();
		}
		return result;
	}
	
	public List<Employee>  ShowAll()
	{
		List<Employee>  empall = new ArrayList<Employee>();
		Employee emp = null;
		try
		{
			PreparedStatement ps = conObj.prepareStatement("Select * from Employee");
			ResultSet rs = ps.executeQuery();
			
			while(rs.next())
			{
				emp = new Employee();
				
				emp.setEmpno(rs.getInt("empno"));
				emp.setEname(rs.getString("empname"));
				emp.setJob(rs.getString("job"));
				emp.setSalary(rs.getInt("salary"));
				emp.setLocation(rs.getString("location"));
				
				empall.add(emp);
			}
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
		
		return empall;
	}

	public Employee SearchEmployee(int eno)
	{
		Employee emp = null;
		try
		{
			PreparedStatement ps = conObj.prepareStatement("Select * from Employee where empno=?");
			ps.setInt(1, eno);
			ResultSet rs = ps.executeQuery();
			
			if(rs.next())
			{
				emp = new Employee();
				
				emp.setEmpno(rs.getInt("empno"));
				emp.setEname(rs.getString("empname"));
				emp.setJob(rs.getString("job"));
				emp.setSalary(rs.getInt("salary"));
				emp.setLocation(rs.getString("location"));
			}			
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
		
		return emp;
	}
	
	public boolean DeleteEmployee(int eno)
	{
		boolean result = false;

		try
		{
			PreparedStatement ps = conObj.prepareStatement("Delete from Employee where empno=?");
			ps.setInt(1, eno);
			int res = ps.executeUpdate();
			if(res>=1)
				result = true;
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}

		return result;
	}
	
	public String UpdateEmpName(Employee emp)
	{
		String result = "Error";
		
		try
		{
			//update employee set empname='new name' where empno=1111
			PreparedStatement ps = conObj.prepareStatement("Update employee set empname=? where empno=?");
			ps.setString(1, emp.getEname());
			ps.setInt(2, emp.getEmpno());
			
			int res = ps.executeUpdate();
			
			if(res>=1)
				result = "Success";
		}
		catch(Exception ex)
		{
			result = ex.getMessage();
		}
		
		return result;
	}
}

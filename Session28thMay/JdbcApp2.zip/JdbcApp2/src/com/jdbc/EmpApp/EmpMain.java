package com.jdbc.EmpApp;
import java.util.*;

public class EmpMain {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		EmpOperations  eo = new EmpOperations();
		Employee emp = null;
		int eno;
		while(true)
		{
			System.out.println("1. Add New Employee\n2. View All Employees\n3. Search Employee\n4. Delete an Employee\n5. Update an Employee\n6. Exit");
			System.out.println("Pick Ur Choice : ");
			int ch = sc.nextInt();
			
			switch(ch)
			{
			case 1:
				emp = new Employee();
				System.out.println("Employee Name : ");
				emp.setEname(sc.next());
				System.out.println("Employee Job : ");
				emp.setJob(sc.next());
				System.out.println("Employee Salary : ");
				emp.setSalary(sc.nextInt());
				System.out.println("Employee Location : ");
				emp.setLocation(sc.next());
				
				String res = eo.AddNewEmployee(emp);
				if(res.equals("Success"))
					System.out.println("New Employee is Added....");
				else
					System.out.println("Error ! Emp not Added.....");
				break;
			case 2:
				List<Employee>  empinfo = eo.ShowAll();

				for(Employee e : empinfo)
				{
					System.out.println(e.getEmpno() + "\t" + e.getEname() + "\t" + e.getJob() + "\t" + e.getSalary() + "\t" + e.getLocation());
				}
				System.out.println("-------------");
				break;
			case 3:
				System.out.println("Enter Employee Number : ");
				eno = sc.nextInt();
				emp = eo.SearchEmployee(eno);
				if(emp!=null)
					System.out.println(emp.getEmpno() + "\t" + emp.getEname() + "\t" + emp.getJob() + "\t" + emp.getSalary() + "\t" + emp.getLocation());
				else
					System.out.println("Employee not found....");
				System.out.println("-----------");
				break;
				
			case 4:
				System.out.println("Enter Employee Number To Delete : ");
				eno = sc.nextInt();
				emp = eo.SearchEmployee(eno);
				if(emp!=null)
				{
					// delete emp 
					if(eo.DeleteEmployee(eno)==true)
						System.out.println("Employee Deleted...");
				}
				else
					System.out.println("Employee not found....");
				System.out.println("-----------");
				break;
			case 5:
				System.out.println("Enter Employee Number To Modify : ");
				eno = sc.nextInt();
				emp = eo.SearchEmployee(eno);
				if(emp!=null)
				{
					System.out.println("Present Name of the Employee : " + emp.getEname());
					System.out.println("New Name of the employee : ");
					emp.setEname(sc.next());
					
					if(eo.UpdateEmpName(emp).equals("Success"))
						System.out.println("Emplyee Name is Modified....");
					else
						System.out.println("Error ! ....");
				}
				else
					System.out.println("Employee not found....");
				System.out.println("-----------");
				break;
			case 6:
				System.out.println("Thanks for Using App");
				System.exit(0);
				
			default:
				System.out.println("Invalid Selection\n----------------------");
			}
		}
	}
}

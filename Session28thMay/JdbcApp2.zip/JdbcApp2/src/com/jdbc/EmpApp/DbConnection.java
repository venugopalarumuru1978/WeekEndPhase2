package com.jdbc.EmpApp;
import java.io.FileReader;
import java.sql.*;
import java.util.Properties;

public class DbConnection {

	public static Connection  GetDbConnection()
	{
		Connection con = null;
		try
		{
			String path =  System.getProperty("user.dir");  // to find location of the currently running application
			path = path + "\\src\\test.properties";
			FileReader fr = new FileReader(path);
			Properties prp = new Properties();
			prp.load(fr);
			
			Class.forName(prp.getProperty("drivername"));
			con = DriverManager.getConnection(prp.getProperty("connString"), prp.getProperty("username"), prp.getProperty("password"));
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return con;
	}
}

package com.jdbc;
import java.sql.*;
import java.util.*;
public class ShowAllStudents {

	public static void main(String[] args) {

		try
		{
			Connection  conObj = DbConnection.GetDbConnection();
			Statement stmt = conObj.createStatement();
			ResultSet  rs = stmt.executeQuery("Select * from Student");
			
			while(rs.next())
			{
				System.out.println("Roll Number : " + rs.getInt("rollno"));
				System.out.println("Student Name : " + rs.getString("sname"));
				System.out.println("Student Course : " + rs.getString("course"));
				System.out.println("Course Fees : " + rs.getFloat("fees"));
				System.out.println("-----------------");
			}
			
			
			conObj.close();
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
	}
}

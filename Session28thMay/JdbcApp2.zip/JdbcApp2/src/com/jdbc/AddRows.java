package com.jdbc;
import java.sql.*;
import java.util.*;
public class AddRows {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Roll Number : ");
		int rno = sc.nextInt();
		System.out.println("Student Name : ");
		String sname = sc.next();
		System.out.println("Student Course : ");
		String course = sc.next();
		System.out.println("Course Fees : ");
		float fees = sc.nextFloat();
		
		//Insert into student(rollno, sname, course, fees) values(1001, 'Lokesh','Java',15000.00);
		
		String inscmd = "Insert into student(rollno, sname, course, fees) values("  + rno + ",'" + sname + "','" + course + "'," + fees + ")";
		System.out.println(inscmd);		
		try
		{
			Connection  conObj = DbConnection.GetDbConnection();
			Statement stmt = conObj.createStatement();
			int res = stmt.executeUpdate(inscmd);
			if(res>=1)
				System.out.println("Row is Added....");
			conObj.close();
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
	}
}

import java.io.FileReader;
import java.util.Properties;

public class Test1 {

	public static void main(String[] args) throws Exception {
		
		String path =  System.getProperty("user.dir");  // to find location of the currently running application
		path = path + "\\src\\test.properties";
		System.out.println(path);
		
		FileReader fr = new FileReader(path);

		Properties prp = new Properties();
		prp.load(fr);
		
		System.out.println(prp.getProperty("sname"));
		System.out.println(prp.getProperty("course"));
		System.out.println(prp.getProperty("fees"));
	}
}

package com.jdbc.servletsinfo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ChangePwd
 */
@WebServlet("/ChangePwd")
public class ChangePwd extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ChangePwd() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		out.print("<hr />");
		out.print("<p style='text-align:center;width:100%'>");
		out.print("<a href='WelcomeCustomer'>Home</a>");
		out.print("&nbsp;&nbsp;|&nbsp;&nbsp;");
		out.print("<a href='ChangePwd'>Change Password</a>");
		out.print("&nbsp;&nbsp;|&nbsp;&nbsp;");
		out.print("<a href='Login.html'>Logout</a>");
		out.print("</p>");
		out.print("<hr />");

		out.print("<form method='POST' action='ModPwd'>");
		out.print("<p style='text-align:center;width:100%'>");
		out.print("<input type='text' name='txtNpwd' placeholder='New Password'>");
		out.print("<br /><br />");
		out.print("<input type='text' name='txtCnpwd' placeholder='Confirm New Password'>");
		out.print("<br /><br />");
		out.print("<input type='submit' value='Change Password'>");
		out.print("</p></form>");
	}

}

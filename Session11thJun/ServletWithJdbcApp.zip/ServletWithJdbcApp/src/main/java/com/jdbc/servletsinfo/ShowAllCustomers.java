package com.jdbc.servletsinfo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jdbc.model.Customer;
import com.jdbc.service.CustomerOperations;

/**
 * Servlet implementation class ShowAllCustomers
 */
@WebServlet("/ShowAllCustomers")
public class ShowAllCustomers extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowAllCustomers() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out =  response.getWriter();
		
		out.print("<hr />");
		out.print("<p style='text-align:center;width:100%'>");
		out.print("<a href='AddCustomer.html'>New Customer</a>");
		out.print("&nbsp;&nbsp;|&nbsp;&nbsp;");
		out.print("<a href='ShowAllCustomers'>Show All Customers</a>");
		out.print("&nbsp;&nbsp;|&nbsp;&nbsp;");
		out.print("<a href='Search.html'>Search Customer</a>");
		out.print("&nbsp;&nbsp;|&nbsp;&nbsp;");
		out.print("<a href='Login.html'>Logout</a>");
		out.print("</p>");
		out.print("<hr />");
		
		CustomerOperations co = new CustomerOperations();
		List<Customer>  call = co.ShowAll();
		
		out.print("<table border='1' width='100%'>");
		out.print("<tr><th>Cust ID</th><th>Cust Name</th><th>Phone</th><th>Email</th><th>Password</th><th>Operations</th></tr>");
		
		for(Customer c : call)
		{
			out.print("<tr>");
			out.print("<td>" + c.getCustid() + "</td>");
			out.print("<td>" + c.getCustname() + "</td>");
			out.print("<td>" + c.getPhone() + "</td>");
			out.print("<td>" + c.getEmail() + "</td>");
			out.print("<td>" + c.getPswd() + "</td>");
			out.print("<td><a href='DeleteCust?cid=" + c.getCustid() + "'>Delete</a></td>");
			out.print("</tr>");
		}
		out.print("</table>");
 	}
}

package com.jdbc.servletsinfo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.jdbc.model.Customer;
import com.jdbc.service.CustomerOperations;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String uname  = request.getParameter("txtUname");
		String pwd = request.getParameter("txtPwd");
		HttpSession session = request.getSession();
		
		if(uname.equals("admin") && pwd.equals("admin@123"))
		{
			session.setAttribute("user", "Administrator");
			response.sendRedirect("ShowAllCustomers");
		}
		else
		{
			CustomerOperations co = new CustomerOperations();
			Customer cust = co.LoginCheck(uname, pwd);
			if(cust!=null)
			{
				session.setAttribute("cust", cust);
				session.setAttribute("user", cust.getCustname());
				response.sendRedirect("WelcomeCustomer");
			}
			else
			{
				out.print("<h2 style='text-align:center;width:100%'>Please check username / password<br />");
				out.print("<a href='Login.html'>Re-Login</a></h2>");
			}
		}
	}
}

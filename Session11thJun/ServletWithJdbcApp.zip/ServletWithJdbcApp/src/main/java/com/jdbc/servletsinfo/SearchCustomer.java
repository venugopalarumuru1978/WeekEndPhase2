package com.jdbc.servletsinfo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jdbc.model.Customer;
import com.jdbc.service.CustomerOperations;

/**
 * Servlet implementation class SearchCustomer
 */
@WebServlet("/SearchCustomer")
public class SearchCustomer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchCustomer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String cno = request.getParameter("txtCid");
		
		response.setContentType("text/html");
		PrintWriter out =  response.getWriter();
		
		CustomerOperations co = new CustomerOperations();
		Customer cust =co.SearchCustomer(Integer.parseInt(cno));
		
		if(cust!=null)
		{
			out.print("<table border='1' width='100%'>");
			out.print("<tr><th>Cust ID</th><th>Cust Name</th><th>Phone</th><th>Email</th><th>Password</th></tr>");
			out.print("<tr>");
			out.print("<td>" + cust.getCustid() + "</td>");
			out.print("<td>" + cust.getCustname() + "</td>");
			out.print("<td>" + cust.getPhone() + "</td>");
			out.print("<td>" + cust.getEmail() + "</td>");
			out.print("<td>" + cust.getPswd() + "</td>");
			out.print("</tr></table");
			out.print("<h1 style='text-align:center;width:100%'><a href='Search.html'>Back</a></h1>");
		}
		else
		{
			out.print("<h1 style=text-align:center;width:100%'>Customer Not Found </h1>");
			out.print("<h1 style='text-align:center;width:100%'><a href='Search.html'>Back</a></h1>");
		}
	}

}

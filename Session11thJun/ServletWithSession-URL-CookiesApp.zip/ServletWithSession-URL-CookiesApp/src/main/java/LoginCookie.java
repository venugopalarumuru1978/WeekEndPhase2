import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginCookie
 */
@WebServlet("/LoginCookie")
public class LoginCookie extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginCookie() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String uname  = request.getParameter("txtUname");
		String pwd = request.getParameter("txtPwd");
		
		if(uname.equals("venugopal")  &&  pwd.equals("12345"))
		{// creating cookie
			//HttpSession session = request.getSession();
			Cookie ck = new Cookie("user", uname);
			ck.setMaxAge(100);
			response.addCookie(ck);
			
			response.sendRedirect("WelcomeCookie");
		}
		else
			response.sendRedirect("Error.html");
	}

}

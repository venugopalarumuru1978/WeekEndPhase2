package com.jdbc.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.jdbc.dbcon.DbConnection;
import com.jdbc.model.Customer;

public class CustomerOperations {

	private Connection conObj = null;
	
	public CustomerOperations()
	{
		conObj = DbConnection.GetDbConnection();
	}
	
	public String AddCustomer(Customer cus)
	{
		String result = "Err";
		
		try
		{
			PreparedStatement ps = conObj.prepareStatement("Insert into Customer values(?,?,?,?,?)");
			ps.setInt(1, cus.getCustid());
			ps.setString(2, cus.getCustname());
			ps.setString(3, cus.getPhone());
			ps.setString(4, cus.getEmail());
			ps.setString(5, cus.getPswd());
			int res = ps.executeUpdate();
			
			if(res>=1)
				result ="Success";
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}

		return result;
	}
	
	public List<Customer>  ShowAll()
	{
		List<Customer>  call = new ArrayList<Customer>();
		
		try
		{
			PreparedStatement ps = conObj.prepareStatement("Select * from Customer");
			ResultSet rs = ps.executeQuery();
			Customer c = null;
			while(rs.next())
			{
				c = new Customer();
				c.setCustid(rs.getInt("custid"));
				c.setCustname(rs.getString("custname"));
				c.setPhone(rs.getString("phone"));
				c.setEmail(rs.getString("email"));
				c.setPswd(rs.getString("pswd"));
				call.add(c);
			}
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
		return call;
	}
	
	public Customer SearchCustomer(int cid)
	{
		Customer c = null;
		try
		{
			PreparedStatement ps = conObj.prepareStatement("Select * from Customer where custid=?");
			ps.setInt(1, cid);
			ResultSet rs = ps.executeQuery();
			if(rs.next())
			{
				c = new Customer();
				c.setCustid(rs.getInt("custid"));
				c.setCustname(rs.getString("custname"));
				c.setPhone(rs.getString("phone"));
				c.setEmail(rs.getString("email"));
				c.setPswd(rs.getString("pswd"));
			}
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
		return c;
	}
}

package com.jdbc.model;
/*
 * Create table customer(custid int primary key, 
custname varchar(20), 
phone varchar(10), email varchar(100), pswd varchar(20));
 */
public class Customer {

	private int custid;
	private String custname;
	private String phone;
	private String email;
	private String pswd;
	
	public int getCustid() {
		return custid;
	}
	public void setCustid(int custid) {
		this.custid = custid;
	}
	public String getCustname() {
		return custname;
	}
	public void setCustname(String custname) {
		this.custname = custname;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPswd() {
		return pswd;
	}
	public void setPswd(String pswd) {
		this.pswd = pswd;
	}
	
	
}

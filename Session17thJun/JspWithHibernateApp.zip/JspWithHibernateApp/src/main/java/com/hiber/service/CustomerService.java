package com.hiber.service;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.hiber.config.HiberConfig;
import com.hiber.model.Customer;

public class CustomerService {

	private SessionFactory  sf = null;
	
	public CustomerService()
	{
		sf = HiberConfig.getSessionFactory();
	}
	
	public void AddNewCustomer(Customer cus)
	{
		Session session = sf.openSession();
		Transaction trans = session.beginTransaction();
		session.save(cus);
		trans.commit();
		session.close();
	}
	
	public List<Customer>  ShowAll()
	{
		Session session = sf.openSession();
	    TypedQuery qry = session.createQuery("from Customer");
	    List<Customer> call = qry.getResultList();
	    return call;
	}
	
	public Customer SearchCustomer(int cno)
	{
		Session session = sf.openSession();
	    TypedQuery qry = session.createQuery("from Customer where custid=:cid");
	    qry.setParameter("cid", cno);
	    List<Customer> call = qry.getResultList();
	    if(call.isEmpty())
	    	return null;
	    
	    return call.get(0);
	}
	
	public String DeleteCustomer(int cno)
	{
		
		String res = "err";
		Session session = sf.openSession();
		Transaction trans = session.beginTransaction();
		TypedQuery qry = session.createQuery("Delete from Customer where custid=:cid");
	    qry.setParameter("cid", cno);
	    int r1 = qry.executeUpdate();
	    trans.commit();
	    if(r1>=1)
	    	res="Success";
	    
	    return res;
	}
	
	public String UpdateCustomer(Customer cus)
	{
		String res = "err";
		Session session = sf.openSession();
		Transaction trans = session.beginTransaction();
		TypedQuery qry = session.createQuery("Update Customer set custname=:cname, email=:em, phone=:ph where custid=:cid");
	    qry.setParameter("cid", cus.getCustid());
	    qry.setParameter("cname", cus.getCustname());
	    qry.setParameter("ph", cus.getPhone());
	    qry.setParameter("em", cus.getEmail());
	    int r1 = qry.executeUpdate();
	    trans.commit();
	    if(r1>=1)
	    	res="Success";
	    
	    return res;
	}

}
